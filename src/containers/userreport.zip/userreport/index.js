import IndexComponent from './IndexComponent'

export default IndexComponent;