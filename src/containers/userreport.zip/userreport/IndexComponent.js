import React from 'react';
import { connect } from 'react-redux';
import ProgressBar from 'react-bootstrap/ProgressBar'
import Collapse from 'react-bootstrap/Collapse'
import IndexComponentStyled from './IndexComponentStyled';
import Header from '../../components/header'
import Leftbar from '../../components/leftbar'
import Graph from '../../components/userreportgraph'
import BARGraph from '../../components/barchart'
import { Redirect } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../../assets/css/style.css';
import Fade from 'react-reveal/Fade';
import $ from 'jquery';
const intialState = {
  email: '',
  password: '',
  emailErr: '',
  passwordErr: '',
  open:false

};

function importAll(r) {
  let images = {};
  r.keys().map((item, index) => { images[item.replace('./', '')] = r(item); });
  return images;
}
function NoData() {
  return (<div style={{ textAlign: 'center' }}>No data</div>)
}
const images = importAll(require.context('../../assets/img/', false, /\.(png|jpe?g|svg)$/));
class Profile extends React.Component {

  constructor(props) {
    super(props)
    this.state = intialState
  }
  setopen = e => {
    if(this.state.open==true)
    this.setState({open:false })
    else
    this.setState({open:true })


  }
 
  componentDidMount() {
    $(document).ready(function () {
      var trigger = $('.hamburger'),
        overlay = $('.overlay'),
        isClosed = false;

      trigger.click(function () {
        hamburger_cross();
      });

      function hamburger_cross() {

        if (isClosed == true) {
          overlay.hide();
          trigger.removeClass('is-open');
          trigger.addClass('is-closed');
          isClosed = false;
        } else {
          overlay.show();
          trigger.removeClass('is-closed');
          trigger.addClass('is-open');
          isClosed = true;
        }
      }

      $('[data-toggle="offcanvas"]').click(function () {
        $('#wrapper').toggleClass('toggled');
      });
    });


    const progress = document.querySelector('.progress-done');
    if (progress) {
      progress.style.width = progress.getAttribute('data-done') + '%';
      progress.style.opacity = 1;
    }

  }


  render() {
    const now = 60;
    let token = localStorage.getItem('token')
    if (!token) return <Redirect to='/' />
    const user = JSON.parse(localStorage.getItem('user'))
    return (

      <React.Fragment>

        <IndexComponentStyled>

        { !token?  <Redirect to='/' /> :''}
        <main id="main">
          <div id="wrapper">
          <Header />
            {/* Sidebar */}
            <Leftbar />
            {/* /#sidebar-wrapper */}
            {/* Page Content */}
            <Fade bottom>
            {/* Page Content */}
            <div className="page-content-wrapper user-report" data-aos="fade-up">
              <div className="container-fluid">
                <div className="row">
                  <div className="col-lg-12 col-md-12 text-right">
                    <div className="dropdown-container">
                      <div className="dropdown show">
                        <a className="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <span>Date</span>
                          Data
                        </a>
                        <div className="dropdown-menu" aria-labelledby="dropdownMenuLink">
                          <a className="dropdown-item" href="#">Data1</a>
                          <a className="dropdown-item" href="#">Data2</a>
                          <a className="dropdown-item" href="#">Data3</a>
                        </div>
                      </div>
                      <div className="dropdown show">
                        <a className="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <span>Region</span>
                          Data
                        </a>
                        <div className="dropdown-menu" aria-labelledby="dropdownMenuLink">
                          <a className="dropdown-item" href="#">Data1</a>
                          <a className="dropdown-item" href="#">Data2</a>
                          <a className="dropdown-item" href="#">Data3</a>
                        </div>
                      </div>
                      <div className="dropdown show">
                        <a className="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <span>Center</span>
                          Data
                        </a>
                        <div className="dropdown-menu" aria-labelledby="dropdownMenuLink">
                          <a className="dropdown-item" href="#">Data1</a>
                          <a className="dropdown-item" href="#">Data2</a>
                          <a className="dropdown-item" href="#">Data3</a>
                        </div>
                      </div>
                      <div className="dropdown show">
                        <a className="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <span>Age</span>
                          Data
                        </a>
                        <div className="dropdown-menu" aria-labelledby="dropdownMenuLink">
                          <a className="dropdown-item" href="#">Data1</a>
                          <a className="dropdown-item" href="#">Data2</a>
                          <a className="dropdown-item" href="#">Data3</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-lg-12 col-md-12">
                    <div className="white-curve-box">
                      <Graph />
                    </div>
                  </div>
                  
                </div>
                <div className="row">
                  <div className="col-lg-6 col-md-12">
                    <div className="white-curve-box small">
                  
                   < BARGraph />
                    </div>
                  </div>
                  <div className="col-lg-6 col-md-12">
                    <div className="white-curve-box small">
                       {/* <div class="progress-container">
                    <span>14/03.2021</span>
                    <ProgressBar>
                      <ProgressBar  variant="success1" now={35} key={1} />
                      <ProgressBar variant="success2" now={20} key={2} />
                      <ProgressBar  variant="success3" now={10} key={3} />
                    </ProgressBar>
                  </div> */}

                  < BARGraph />
                    </div>
                  </div>
                  <div className="col-lg-6 col-md-12">
                    <div className="white-curve-box small">
                        < BARGraph />
                    </div>
                  </div>
               
                
                  <div className="col-lg-6 col-md-12">
                    <div className="white-curve-box small">
                        < BARGraph />
                    </div>
                  </div>
                
               
                  </div>
              </div>
            </div>
           </Fade>
          </div>
          {/* /#page-content-wrapper */}
          {/* /#wrapper */}
        </main>{/* End #main */}
        {/* ======= Footer ======= */}
        <footer id="footer">
        </footer>{/* End Footer */}
        

  </IndexComponentStyled>


      </React.Fragment >

    );
  }
}

const mapStateToProps = (state) => {
  return {
    uservalue: state.uservalue,
    usererror: state.usererror,
    email: state.updateUserRecord
  }


}


export default connect(mapStateToProps)(Profile);





